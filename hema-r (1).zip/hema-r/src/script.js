// Simple alert on page load
window.onload = () => {
    console.log("Welcome to my portfolio!");
  };